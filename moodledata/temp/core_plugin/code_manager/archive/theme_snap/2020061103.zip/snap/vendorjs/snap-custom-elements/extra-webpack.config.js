module.exports = {
  output: {
    jsonpFunction: 'webpackJsonpSnapCE'
  }
};
