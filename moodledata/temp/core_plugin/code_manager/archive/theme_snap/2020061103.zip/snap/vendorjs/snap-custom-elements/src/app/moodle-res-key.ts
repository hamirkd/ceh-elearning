import {MoodleResArgs} from "./moodle-res-args";

export class MoodleResKey {
  sessKey: string;
  args: MoodleResArgs;
}
